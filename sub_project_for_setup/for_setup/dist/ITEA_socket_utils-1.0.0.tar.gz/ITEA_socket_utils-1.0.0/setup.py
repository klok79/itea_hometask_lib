from setuptools import setup

setup(name='ITEA_socket_utils',
      version='1.0.0',
      description='a two functions for write-read sockets',
      author='None',
      packages=['ITEA_socket_utils',],
      # install_requires=req
      )