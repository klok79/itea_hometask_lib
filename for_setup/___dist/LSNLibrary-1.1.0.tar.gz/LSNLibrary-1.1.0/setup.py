from setuptools import setup

# with open('requrements.txt') as f:
#     req = f.read().splitlines()
setup(name='LSNLibrary',
      version='1.1.0',
      description='a library packed test',
      author='None',
      packages=['LSNLibrary','LSNLibrary.lib_utils'],
      # install_requires=req
      )